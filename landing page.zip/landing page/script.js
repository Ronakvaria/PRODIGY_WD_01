document.addEventListener("DOMContentLoaded", function() {
    const navbar = document.getElementById("navbar");
    const sections = document.querySelectorAll("section");

    window.addEventListener("scroll", function() {
        const scrollPosition = window.scrollY;

        // Change background color of the navbar when scrolled
        if (scrollPosition > 50) {
            navbar.style.backgroundColor = "#555";
        } else {
            navbar.style.backgroundColor = "#333";
        }

        // Highlight the corresponding menu item based on the section in view
        sections.forEach((section) => {
            const sectionTop = section.offsetTop - 50;
            const sectionBottom = sectionTop + section.offsetHeight;

            if (scrollPosition >= sectionTop && scrollPosition < sectionBottom) {
                const id = section.getAttribute("id");
                setActiveMenuItem(id);
            }
        });
    });

    // Helper function to set the active menu item
    function setActiveMenuItem(id) {
        const menuItems = document.querySelectorAll("#navbar a");
        menuItems.forEach((item) => {
            item.classList.remove("active");
            if (item.getAttribute("href") === `#${id}`) {
                item.classList.add("active");
            }
        });
    }
});
